//Ruobing Liu
//2022F CS 501-WS2
/**
 * opening the input file
reading from the input file
closing the input file
 * default constructor
overloaded constructor, if needed
mutator methods
accessor methods
 *
 */
import java.util.Scanner;
import java.util.Collections; 
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
public class InputFile {
	//Use ArrayList to store words in the file.
	ArrayList<String> responses;
	public InputFile() throws FileNotFoundException {
		buildList();
	}
	private void buildList() throws FileNotFoundException{
		ArrayList<String> list=new ArrayList<>();
		String[] arrOfStr;
		System.out.println(" Opening input file...\n");
		Scanner inputFile=new Scanner(new File("inPoem.txt"));
		//Strip punctuation symbols off the original input texts.
		while (inputFile.hasNext()) {
			String line = inputFile.nextLine();
			arrOfStr = line.split("[, !\"'-+=%^#`~_|/:;?.@]+");
			for (String a : arrOfStr) {
				list.add(a.strip());
			}
		}
		//Sort the ArrayList of words in the order of capital letter and other orders, based on Collections.sort.
		Collections.sort(list);
		responses=list;
	}
	//Mutate word ArrayList.
	public void muatateElement(ArrayList<String> strList) {
		responses=strList;
	}
	//Get ArrayList.
	public ArrayList<String> accessElement(){
		return responses;
	}
}
