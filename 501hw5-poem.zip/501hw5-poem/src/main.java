//Ruobing Liu
//2022F CS 501-WS2
/**
 * beginning statement or title with a short description of what the program is doing
column headings
list of words (punctuation is discarded) found in the input file sorted in ascending order
the frequency of each word in the input file
whether the word is a palindrome
 *
 */

import java.io.FileNotFoundException;
import java.util.ArrayList;
public class main {
	public static void main(String[] args) throws FileNotFoundException {
		//Program starts.
		System.out.println("Poem Word Analysis\n");
		//Instantiate InputFile class as in.
		InputFile in=new InputFile();
		//Get sorted original words ArrayList ori from in.
		ArrayList<String> ori= in.accessElement();
		//Use ori to instantiate Analysis class.
		Analysis a = new Analysis(ori);
		//Call frequency() and Palindrome methods to calculate frequency and palindrome state.
		a.frequency();
		a.Palindrome();
		//Organize output format.
		System.out.println(" Word Frequency Palindrome");
		System.out.println("____________________________");
		//Get each word, frequency and palindrome state from each ArrayList, and output.
		for (int i=0;i<a.wordList().size();i++) {
			System.out.printf(" %-10s%-10s%-10s\n",a.wordList().get(i),a.freqList().get(i),a.paList().get(i));
		}
		System.out.println("\n End of results.");
	}
}
