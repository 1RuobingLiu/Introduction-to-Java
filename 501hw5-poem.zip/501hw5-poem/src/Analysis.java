//Ruobing Liu
//2022F CS 501-WS2
/**
 * searching/adding words to an ArrayList or parallel array
updating the frequency value of a word
discovering if the word is a palindrome
 default constructor
overloaded constructor, if needed
mutator methods
accessor methods
 */
import java.io.FileNotFoundException;
import java.util.ArrayList;
public class Analysis {
	//Receive the sorted original word list from InputFile (redundant words), storing in another ArrayList after non-redundant processing.
	ArrayList<String> wordlist_ori;
	ArrayList<String> wordlist_aft=new ArrayList<String>() ;
	//Use ArrayList to store frequency and palindrome state of each word.
	ArrayList<Integer> freqlist=new ArrayList<Integer>();
	ArrayList<Boolean> palist=new ArrayList<Boolean>();
	//Speculate last index of words in sorted original ArrayList to create non-redundant ArrayList.
	public Analysis(ArrayList<String> ori) {
		wordlist_ori=ori;
		for (int i=0;i<wordlist_ori.size();i++) {
			if (i==wordlist_ori.lastIndexOf(wordlist_ori.get(i))) {
				wordlist_aft.add(wordlist_ori.get(i));
			}
		}
	}
	//Check the last and first index of the words from non-redundant word ArrayList, to calculate frequency in the original sorted redundant word ArrayList. Store in freqlist.
	public void frequency() {
		for (int i=0;i<wordlist_aft.size();i++) {
			int fre=wordlist_ori.lastIndexOf(wordlist_aft.get(i))-wordlist_ori.indexOf(wordlist_aft.get(i))+1;
			freqlist.add(fre);
		}
	}
	//Use isPalin method to check each word in non-redundant ArrayList, and store the boolean in the palist.
	public void Palindrome() {
		for (int i=0;i<wordlist_aft.size();i++) {
			String str=wordlist_aft.get(i);
			palist.add(isPalin(str));
		}
	}
	//Check if a word is palindrome, by comparing the letters from the front and back.
	public boolean isPalin(String str) {
		for(int i=0;i<str.length()/2;i++) {
				if (str.charAt(i)!=str.charAt(str.length()-i-1)) {
					return false;
				}
		}
		return true;
	}
	//Add word to wordList if the word is not in the wordList.
	public void add_wordList(String word){
		if (wordlist_aft.indexOf(word)<0){
			wordlist_aft.add(word);
		}
	}
	//Search if a word in the wordList.
	public void searchWord(String word) {
		if(wordlist_aft.contains(word)==true) {
			System.out.print("This word is in the arraylist.");
		}
		else {
			System.out.print("This word is not in the arraylist.");
		}
	}
	//Get wordlist_aft.
	public ArrayList<String> wordList(){
		return wordlist_aft;
	}
	//Get freqlist.
	public ArrayList<Integer> freqList(){
		return freqlist;
	}
	//Get palist.
	public ArrayList<Boolean> paList(){
		return palist;
	}
}
