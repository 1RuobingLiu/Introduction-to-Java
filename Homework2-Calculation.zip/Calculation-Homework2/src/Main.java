//Ruobing Liu
//2022F CS 501-WS2
/**
 * This program will firstly prompt the user to input two double numbers, and then calculate them in the following orders, 
   as required in the Project2 specification:
The initial value of the instance field:  value
The value after adding num1
The value after multiplying by 3
The value after subtracting num2
The value after dividing by 2
The value after calling the clear() method
 */

import java.util.Scanner; 
public class Main {

	public static void main(String[] args) {
		
		//beginning
		System.out.print("The Calculator Program\n\n");
		
		//input two numbers for calculation
		Scanner keyboard = new Scanner(System.in);
		double f_num, s_num;
		System.out.print("Enter the first number: ");
		f_num = keyboard.nextDouble();
		System.out.print("Enter the second number: ");
		s_num = keyboard.nextDouble();
		System.out.print("\n\n");
		
		//create Calculator class
		Calculator cal = new Calculator();

		/*
		 * /caculation process
		 */
		System.out.print("Output:\n\n");
		
		//orignial value
		System.out.print(String.format("The number currently stored in the variable value is:\n%.1f",cal.getValue()));
		//added first number
		cal.add(f_num);
		System.out.print(String.format("\nThe value added by first number is:\n%.1f",cal.getValue()));
		//multiplied by 3
		cal.multiply(3);
		System.out.print(String.format("\nThe value multiplied by 3 is:\n%.1f",cal.getValue()));
		//substracted by second number
		cal.subtract(s_num);
		System.out.print(String.format("\nThe value substracted by the second number is:\n%.1f",cal.getValue()));
		//divided by 2
		cal.divide(2);
		System.out.print(String.format("\nThe value divided by 2 is:\n%.1f",cal.getValue()));
		//clear value
		cal.clear();
		System.out.print(String.format("\nNow the value is cleared to\n%.1f",cal.getValue())+"\n\nEnd of results.");
		
	}

}
