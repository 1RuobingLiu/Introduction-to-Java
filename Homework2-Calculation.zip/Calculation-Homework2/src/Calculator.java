//Ruobing Liu
//2022F CS 501-WS2
/**
 * As shown in Canvas Project2 specification, Class Calculator is created and contains the following:
private member variable named value
public Calculator() - Constructor method to set the member field to 0.0
public void add(double val) - add the parameter to the member field
public void subtract(double val) - subtract the parameter from the member field
public void multiply(double val) - multiply the member field by the parameter
public void divide(double val) - divide the member field by the parameter
public void clear( ) - set the member field to 0.0
public double getValue( ) - return the member field
 */

public class Calculator {
	//original member field value
	private double value;
	
	//Constructor method to set the member field to 0.0
	 public Calculator()
	 {
		 value=0.0;
	 }
	 
	 //add the parameter val to the member field
	 public void add(double val) {
		 value += val;
	 }
	 
	 //subtract the parameter from the member field
	 public void subtract(double val) {
		 value -=val;
	 }
	 
	 // multiply the member field by the parameter
	 public void multiply(double val) {
		 value*=val;
	 }
	 
	 //divide the member field by the parameter
	 public void divide(double val) {
		 value/=val;
	 }
	 
	 //set the member field to 0.0
	 public void clear( ) {
		 value=0.0;
	 }
	 
	 //return the member field
	 public double getValue( ) {
		 return value;
	 }
}
