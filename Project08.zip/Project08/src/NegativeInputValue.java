import javax.swing.JOptionPane;

import javafx.scene.control.TextField;


public class NegativeInputValue extends RuntimeException {
	// The following constructor accepts the inputValue that was given as the
	// weight.
	public NegativeInputValue(TextField inputValue) {
		super("Error: Negative input value is " + inputValue.getText() + ".");
		JOptionPane.showMessageDialog(null,
				"It is a negative number: " + inputValue.getText() + ", please entery again.");
		inputValue.setText("");
		inputValue.requestFocus();
	}

}
