package hw8;
import java.io.File;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

import hw8.EmptyStringException;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.control.Button;

public class PlanetInformation extends Application {
	String str, result;
	
	ArrayList<Planet> tempList;
	Label title = new Label("Please select a planet:");
	Label detail = new Label("Here are the certain details of the planet:");
	CheckBox chkSurface;
	CheckBox chkCircumference;
	CheckBox chkDistance;
	CheckBox chkWeight;
	Label areaAns;
	Label circumferenceAns;
	Label distanceAns;
	Label convertAns;
	TextField weightTextField;
	Button okButton;
	static final double PI = 3.14159;
	double area;
	double circumference;
	double distance;
	double weightRatio;
	double weight;

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) {	
		String filePth= "PlanetInfo.txt";
		File file = new File(filePth);
		if(!file.exists()){
			throw new FileNotFoundException(filePth);
		}
		else {
			Planet p = new Planet();
			ArrayList<Planet> tempList = p.planets;
		}
		//create the RadioButton controls.
		RadioButton mercuryRadio = new RadioButton("Mercury");
		RadioButton venusRadio = new RadioButton("Venus");
		RadioButton earthRadio = new RadioButton("Earth");
		RadioButton marsRadio = new RadioButton("Mars");
		RadioButton jupiterRadio = new RadioButton("Jupiter");
		RadioButton saturnRadio = new RadioButton("Saturn");
		RadioButton uranusRadio = new RadioButton("Uranus");
		RadioButton neptuneRadio = new RadioButton("Neptune");
		// Add the RadioButtons to a ToggleGroup.
		ToggleGroup radioGroup = new ToggleGroup();
		mercuryRadio.setToggleGroup(radioGroup);
		venusRadio.setToggleGroup(radioGroup);
		earthRadio.setToggleGroup(radioGroup);
		marsRadio.setToggleGroup(radioGroup);
		jupiterRadio.setToggleGroup(radioGroup);
		saturnRadio.setToggleGroup(radioGroup);
		uranusRadio.setToggleGroup(radioGroup);
		neptuneRadio.setToggleGroup(radioGroup);		
		// Register an ActionEvent handler for the mercuryRadioRadio.
		radioGroup.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
			public void changed(ObservableValue<? extends Toggle> ob, Toggle o, Toggle n) {
				RadioButton rb = (RadioButton) radioGroup.getSelectedToggle();
				if (rb != null) {
					str = rb.getText();
					for (int i = 0; i < tempList.size(); i++) {
						if (tempList.get(i).getName().equals(str)) {
							double radius = Double.parseDouble(tempList.get(i).getRadius());
							area = 4 * PI * radius * radius;
							circumference = 2 * PI * radius;
							distance = Double.parseDouble(tempList.get(i).getDistance());
							weightRatio = Double.parseDouble(tempList.get(i).getWeightRatio());
						}
					}
					// change the label
					str = null;
					result = null;
				}
			}
		});		
		// create checkBox controls.
		chkSurface = new CheckBox("Calculate surface area of the planet (measured in km)");
		chkCircumference = new CheckBox("Calculate circumference of the planet (measured in km)");
		chkDistance = new CheckBox("Calculate distance from the sun (measured in AU)");
		chkWeight = new CheckBox("Calculate corresponding weight on the planet (measured kg)");
		weightTextField = new TextField();
		// create the Disply Button control.
		Button displayButton = new Button("Calculate");
		// Register the event handler
		displayButton.setOnAction(new TotalButtonHandler());
		// create labels for answers.
		areaAns = new Label("");
		circumferenceAns = new Label("");
		distanceAns = new Label("");
		convertAns = new Label("");
		VBox radioVBox = new VBox(10, mercuryRadio, venusRadio, earthRadio, marsRadio, jupiterRadio, saturnRadio,
				uranusRadio, neptuneRadio);
		HBox hboxCalculate = new HBox(10, chkWeight, weightTextField);
		VBox checkVBox = new VBox(10, chkSurface, chkCircumference, chkDistance, hboxCalculate);
		VBox choiceMain = new VBox(10, title, radioVBox, checkVBox, displayButton);
		VBox answerMain = new VBox(10, detail, areaAns, circumferenceAns, distanceAns, convertAns);
		HBox hboxMain = new HBox(80, choiceMain, answerMain);
		choiceMain.setAlignment(Pos.TOP_LEFT);
		answerMain.setAlignment(Pos.TOP_LEFT);
		hboxMain.setPadding(new Insets(40));
		Scene scene = new Scene(hboxMain, 1000, 500);
		// add the scene to the stage
		primaryStage.setScene(scene);
		// show the window
		primaryStage.show();
		
	}
	
	class TotalButtonHandler implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent event) throws InputMismatchException,NegativeInputValue,EmptyStringException{
			if (chkSurface.isSelected()) {
				areaAns.setText("Surface area of the planet chosen: " + String.format("%,.2f", area) + " sq km.");
			}
			if (chkCircumference.isSelected()) {
				circumferenceAns.setText(
						"Circumference of the planet chosen: " + String.format("%,.2f", circumference) + " km.");
			}
			if (chkDistance.isSelected()) {
				distanceAns.setText("Distance from the sun: " + String.format("%,.2f", distance) + " AU.");
			}
			if (chkWeight.isSelected()) {
				if (weightTextField.getText() == null) {
					throw new EmptyStringException(weightTextField);
				} else {
					if (!isDigit(weightTextField.getText())) {
						InputMismatchException e = new InputMismatchException(weightTextField.getText());
						throw e;
						
					}else if(Double.parseDouble(weightTextField.getText()) < 0) {
						throw new NegativeInputValue(weightTextField,weightTextField.getText());
					}
					weight = Double.parseDouble(weightTextField.getText());
					double convertedWeight = Double.valueOf(weight) * weightRatio;
					convertAns.setText(
							"Corresponding weight on the planet: " + String.format("%,.2f", convertedWeight) + " kg.");
				}
			}			

		}
		private boolean isDigit(String  string) {
		  
		        if (string == null)
		            return false;
		        Pattern pattern = Pattern.compile("^-?\\d+(\\.\\d+)?$");
		        return pattern.matcher(string).matches();
		    }

	}
	class InputMismatchException extends RuntimeException{
		private static final long serialVersionUID = 1L;

		// The following constructor accepts the inputValue that was given as the
		// weight.
		public InputMismatchException(String str) {
			super("Error: Mismatched input value is.");
			JOptionPane.showMessageDialog(null, "It is a mismatched input value: , please entery again.");
			
		}
	}
	class EmptyStringException extends RuntimeException {
		// The following constructor accepts the inputValue that was given as the
		// weight.
		public EmptyStringException(TextField inputValue) {
			super("Error: Empty input value.");
			JOptionPane.showMessageDialog(null, "Empty input value, please entery again.");
			inputValue.setText("");
			inputValue.requestFocus();
		}

	}
	class NegativeInputValue extends RuntimeException {
		// The following constructor accepts the inputValue that was given as the
		// weight.
		public NegativeInputValue(TextField inputValue,String s) {
			super("Error: Negative input value is " + s + ".");
			JOptionPane.showMessageDialog(null,
					"It is a negative number: " + s+ ", please entery again.");
			inputValue.setText("");
			inputValue.requestFocus();
		}

	}
	class FileNotFoundException extends RuntimeException{
		public FileNotFoundException  (String s) {
			super("FileNotFoundException"+s);
			JOptionPane.showMessageDialog(null, "FileNotFoundException"+s);
			System.exit(0);
		}
	}

}