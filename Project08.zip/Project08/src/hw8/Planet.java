package hw8;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Planet {
	private String name;
	private String radius;
	private String weightRatio;
	private String distance;
	ArrayList<Planet> planets = new ArrayList<Planet>();
	// set a array to store moive details.
	String[] planetDetail;
	// set four variables to represent title, year, genre and rating.
	String pName;
	String pRadius;
	String pRatio;
	String pDistance;
	
	public Planet() {
		fileInfo();
	}
	
	public Planet(String name, String radius, String weightRatio, String distance) {
		this.name = name;
		this.radius = radius;
		this.weightRatio = weightRatio;
		this.distance = distance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRadius() {
		return radius;
	}

	public void setRadius(String radius) {
		this.radius = radius;
	}

	public String getWeightRatio() {
		return weightRatio;
	}

	public void setWeightRatio(String weightRatio) {
		this.weightRatio = weightRatio;
	}

	public String getDistance() {
		return distance;
	}

	public void setDistance(String distance) {
		this.distance = distance;
	}
	
	// set a toString method.
	public String toString() {
		String res = "";
		res += name + radius + weightRatio + distance;
		return res;
	}
	
	// set a fileInfo method to read the planet informations from the input file.
	public ArrayList<Planet> fileInfo() {
		String inputName = "PlanetInfo.txt";
		try {
			// Opening the input file.
			FileInputStream in = new FileInputStream(inputName);
			Scanner inputFile = new Scanner(in);
			// Read from the input file.
			while (inputFile.hasNext()) {
				// Read the next line.
				String next = inputFile.nextLine();
				// use split() method to get each detail.
				planetDetail = next.split(",");
				pName = planetDetail[0];
				pRadius = planetDetail[1];
				// remove the space after the comma.
				pRadius = pRadius.trim();
				pRatio = planetDetail[2];
				pRatio = pRatio.trim();
				pDistance = planetDetail[3];
				pDistance = pDistance.trim();
				Planet p = new Planet(pName, pRadius, pRatio, pDistance);
				// add all planets information to the movies.
				planets.add(p);
			}
			// Close the file.
			inputFile.close();
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		}
		return planets;
	}
}
