package hw8;
import javax.swing.JOptionPane;
import javafx.scene.control.TextField;

public class EmptyStringException extends RuntimeException {
	// The following constructor accepts the inputValue that was given as the
	// weight.
	public EmptyStringException(TextField inputValue) {
		super("Error: Empty input value.");
		JOptionPane.showMessageDialog(null, "Empty input value, please entery again.");
		inputValue.setText("");
		inputValue.requestFocus();
	}

}
