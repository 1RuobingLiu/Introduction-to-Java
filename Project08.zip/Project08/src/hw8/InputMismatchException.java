package hw8;
import javax.swing.JOptionPane;
import javafx.scene.control.TextField;

public class InputMismatchException extends RuntimeException{
	private static final long serialVersionUID = 1L;

	// The following constructor accepts the inputValue that was given as the
	// weight.
	public InputMismatchException(String str) {
		super("Error: Mismatched input value is.");
		JOptionPane.showMessageDialog(null, "It is a mismatched input value: , please entery again.");
		
	}
}