package hw8;
import javax.swing.JOptionPane;

import javafx.scene.control.TextField;


public class NegativeInputValue extends RuntimeException {
	// The following constructor accepts the inputValue that was given as the
	// weight.
	public NegativeInputValue(TextField inputValue,String s) {
		super("Error: Negative input value is " + s + ".");
		JOptionPane.showMessageDialog(null,
				"It is a negative number: " + s+ ", please entery again.");
		inputValue.setText("");
		inputValue.requestFocus();
	}

}
