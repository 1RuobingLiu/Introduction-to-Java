//Ruobing Liu
//2022F CS 501-WS2
/**
 * This program is written to encrypt each letter in the input file Oct.txt (in the current directory), to output file EncryptOct1.txt (also in the current directory).
 * The encryption rule is as follows(referenced from Canvas Program 3 description):
	For each letter read in from the input file, add 3 letters to the value of the input letter. 
	If a letter is uppercase in the input file, the encrypted letter should be converted to a lowercase character in the output file.  
	If a letter is lowercase in the input file, the encrypted letter should be converted to an uppercase character in the output file.  
	For example, if the input letter is an A then the encrypted letter would be the letter d; If the input letter from the input file is an X then the encrypted letter would be the letter a.
	All spaces, digits, punctuation, and special characters do not need to be encrypted at this level. Simply write the space, punctuation, or special character to the output file as is.
	Since the input file will be of various lengths, the program will read until end of file.
 *
 */
import java.util.Scanner;
import java.io.*;
public class Encryption_method {

	public static void main(String[] args) throws IOException {
		//Program starts.
		System.out.println("Encryption Level 1\n\n");
		
		//Create output file for later output.
		PrintWriter outputFile = new PrintWriter("EncryptOct1.txt");
		
		//Open the input file for encryption. Start reading.
		System.out.println("Opening input file....\n\n");
		File myFile = new File("Oct1.txt");
		Scanner inputFile = new Scanner(myFile);
		
		//Reading each line of the input file, when the reading has not yet reached the end of file.
		System.out.println("Encrypting....\n\n");
		while (inputFile.hasNext()) {
			String line = inputFile.nextLine();
			
			//Each letter in each line, convert begins.
			for (int i=0;i<line.length();i++) {
				//Get the Unicode of original letter from the input file.
				int unic_str=(int)line.charAt(i);
				//Set the converted letter variable en_str.
				char en_str;
				//Uppercase letters A~Z ：65~90 to lowercase letters  a~z ：97~122.(Unicode)
				if (unic_str>=65 && unic_str<=87) {
					en_str=(char)(unic_str+35);
				}
				else if (unic_str>87 && unic_str<=90) {
					en_str=(char)(unic_str+9);
				}
				//Lowercase letters  a~z ：97~122 to ppercase letters A~Z ：65~90.(Unicode)
				else if (unic_str>=97 && unic_str<=119) {
					en_str=(char)(unic_str-29);
				}
				else if (unic_str>119 && unic_str<=122) {
					en_str=(char)(unic_str-55);
				}
				//Other characters other than letters keep the original value for output.
				else {
					en_str=(char)(unic_str);
				}
				//Write the encrypted character in the output file.
				outputFile.print(en_str);
				
				//Turn to next line for output.
				if (i==line.length()-1) {
					outputFile.print("\n");
				}
			}
			
		}
		
		//After converted all characters, close both of the files.
		inputFile.close();
		outputFile.close();
		System.out.println("Encryption complete.\n\n\n");
		System.out.println("End of program.");
	}

}
