//Ruobing Liu
//2022F CS 501-WS2
/**
 * This program describes a triangle of circle for area calculation.
 */
public class Triangle {
	private double base;
	private double height;
	private double area;
	
	//Default and overloaded constructors.
	public Triangle() {
		this.base=0.0;
		this.height=0.0;
	}
	public Triangle(double k,double i) {
		this.base=k;
		this.height=i;
	}
	
	//Accessors and mutators.
	public double getBase(){
		return this.base;
	}
	public void setBase(double k){
		this.base=k;
	}
	public double getHeight(){
		return this.height;
	}
	public void setHeight(double i){
		this.height=i;
	}
	public void calArea() {
		this.area=this.base*this.height/2;
	}
	public double getArea() {
		return this.area;
	}
}
