//Ruobing Liu
//2022F CS 501-WS2
/**
 * This program uses object-oriented programming principles that will demonstrate the use of multiple classes,
 * to calculate the area of selected shape (circle, rectangle or triangle).
 */
import java.util.Scanner;
public class calculation {
	
	//Call methods for option and area calculation input and display.
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		char option=' ';
		option=displayMenu(scan,option);
		areaConversion(option);
		scan.close();
	}
	
	//Display option menu for circle, rectangle or triangle.
	public static char displayMenu(Scanner scan, char opt) {
		System.out.println("Which shape would you like to calculate area for?(circle/rectangle/triangle)");
		System.out.println("Press c/C for circle.");
		System.out.println("Press r/R for rectangle.");
		System.out.println("Press t/T for triangle.");
		System.out.println("Your choice:");
		opt=scan.next().charAt(0);
		opt=Character.toLowerCase(opt);
		opt=validateOpt(scan,opt);
		return opt;
	}
	
	//Validate the option input: if the input out of options, retry.
	public static char validateOpt (Scanner scan, char op){
		while(op!='c'&&op!='C'&&op!='R'&&op!='r'&&op!='T'&&op!='t') {
			System.out.println("Invalid entry, please retry:");
			op=scan.next().charAt(0);
			op=Character.toLowerCase(op);
		}
		return op;
	}

	//Get number from input.
	public static double getNum(Scanner scan, double num) {
		System.out.println("Enter input number in cm");
		num=scan.nextDouble();
		return num;
	}
	
	//Validate input number: if input numbers <=0, retry.
	public static double validateNum (Scanner scan, double num){
		while(num<=0) {
			System.out.println("Invalid entry, please enter positive number:");
			num=scan.nextDouble();
		}
		return num;
	}
	
	//Use if/else branches of option to proceed the area calculation.
	public static void areaConversion(char opt) {
		Scanner scan=new Scanner(System.in);
		if (opt=='c'||opt=='C') {
			double radius=0;
			System.out.println("Please enter radius of the circle:");
			radius=getNum(scan,radius);
			radius=validateNum(scan,radius);
			Circle cir=new Circle();
			cir.setRadius(radius);
			cir.calArea();
			System.out.printf("The radius of the circle is %.2f cm.\n",cir.getRadius());
			System.out.printf("The area of the circle is %.2f cm square.\n",cir.getArea());
		}
		else if(opt=='r'||opt=='R') {
			double length=0;
			double width=0;
			System.out.println("Please enter length of the rectangle:");
			length=getNum(scan,length);
			length=validateNum(scan,length);
			System.out.println("Please enter width of the rectangle:");
			width=getNum(scan,width);
			width=validateNum(scan,width);
			Rectangle rec=new Rectangle();
			rec.setLength(length);
			rec.setWidth(width);
			rec.calArea();
			System.out.printf("The length of the rectangle is %.2f cm.\n",rec.getLength());
			System.out.printf("The width of the rectangle is %.2f cm.\n",rec.getWidth());
			System.out.printf("The area of the rectangle is %.2f cm square.\n",rec.getArea());
		}
		else {
			double base=0;
			double height=0;
			System.out.println("Please enter base of the triangle:");
			base=getNum(scan,base);
			base=validateNum(scan,base);
			System.out.println("Please enter height of the triangle:");
			height=getNum(scan,height);
			height=validateNum(scan,height);
			Triangle tri=new Triangle();
			tri.setBase(base);
			tri.setHeight(height);
			tri.calArea();
			System.out.printf("The base of the triangle is %.2f cm.\n",tri.getBase());
			System.out.printf("The height of the triangle is %.2f cm.\n",tri.getHeight());
			System.out.printf("The area of the triangle is %.2f cm square.\n",tri.getArea());
		}
		scan.close();
	}
}
