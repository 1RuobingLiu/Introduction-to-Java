//Ruobing Liu
//2022F CS 501-WS2
/**
 * This program describes a class of circle for area calculation.
 */
public class Circle {
	private double radius;
	private final double PI=3.14159;
	private double area;
	
	//Default and overloaded constructors.
	public Circle() {
		this.radius=0.0;
	}
	public Circle(double k) {
		this.radius=k;
	}
	
	//Accessors and mutators.
	public double getRadius(){
		return this.radius;
	}
	public void setRadius(double k){
		this.radius=k;
	}
	public void calArea() {
		this.area=radius*radius*PI;
	}
	public double getArea() {
		return this.area;
	}
}
