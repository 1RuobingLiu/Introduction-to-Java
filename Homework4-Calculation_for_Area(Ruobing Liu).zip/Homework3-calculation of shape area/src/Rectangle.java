//Ruobing Liu
//2022F CS 501-WS2
/**
 * This program describes a rectangle of circle for area calculation.
 */
public class Rectangle {
	private double length;
	private double width;
	private double area;
	
	//Default and overloaded constructors.
	public Rectangle() {
		this.length=0.0;
		this.width=0.0;
	}
	public Rectangle(double k,double i) {
		this.length=k;
		this.width=i;
	}
	
	//Accessors and mutators.
	public double getLength(){
		return this.length;
	}
	public void setLength(double k){
		this.length=k;
	}
	public double getWidth(){
		return this.width;
	}
	public void setWidth(double i){
		this.width=i;
	}
	public void calArea() {
		this.area=length*width;
	}
	public double getArea() {
		return this.area;
	}
}
